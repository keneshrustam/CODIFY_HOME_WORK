//! Инкременты и декременты (постфиксные и префиксные)
//? Инкремент - увеличение на 1
//? Декремент - уменьшение на 1

// let i = 0

// i++ // Инкремент (постфиксный) 1

// i-- // Декремент (постфиксный) 0

// ++i // Инкремент (префиксный) 1

// --i // Декремент (префиксный) 0


// console.log(i++) // 0
// console.log(i) // 1

//! Циклы - есть 5 видов

//* for

//! Задача 1
// #
// ##
// ###
// ####
// #####

// console.log("#")
// console.log("##")
// console.log("###")
// console.log("####")
// console.log("#####")

//? 1 вариант
// let symb = ""

// for(let i = 0; i < 5; i++) {
//     symb += "#"
//     console.log(symb)
// }

//? 2 вариант
// for(let i = "#"; i.length <= 5; i += "#") {
//     console.log(i)
// }

//! Задача 2
// "# # #"
// " # # #"
// "# # #"
// " # # #"
// "# # #"
// " # # #"

// console.log("# # #")
// console.log(" # # #")
// console.log("# # #")
// console.log(" # # #")
// console.log("# # #")
// console.log(" # # #")

//? 1 вариант
// for(let i = 0; i < 6; i++) {
//     if(i % 2 === 0 ) console.log("# # #")
//     else console.log(" # # #")
// }

//? 2 вариант
// for(let i = 0; i < 6; i++) {
//     console.log(i % 2 === 0 ? "# # #" : " # # #")
// }

//! Задача 3
// 1
// 2
// 3
// 4
// 5

// const arr = [1,2,3,4,5]

// for(let i = 0; i < arr.length;i++) {
//     console.log(arr[i])
// }

//! Задача 4

// 2
// 4
// 6
// 8
// 10

// const arr = [0,1,2,3,4,5,6,7,8,9,10]

//? Вариант 1
// for(let i = 0; i < arr.length; i++) {
//     if(!arr[i]) {
//         continue
//     }
//     arr[i] % 2 === 0 && console.log(arr[i])
// }

//? Вариант 2
// for(let i = 2; i < arr.length; i += 2) {
//     console.log(arr[i])
// }


//* for of

// const arr = [1,2,3,4,5]
// const strArr = ['123', 'asd', 'zxc']

// for(const item of strArr) {
//     console.log(item)
// }


//* for in

// const obj = {
//     name: 'Aidar',
//     age: 20,
//     lang: 'KY'
// }

// for(const key in obj) {
//     console.log(key)
// }

//? Задача 1

// name: Aidar
// age: 20
// lang: KY

// for(const key in obj) {
//     console.log(`${key}: ${obj[key]}`)
// }

//? Задача 2

// const obj = {
//     1: 10,
//     2: 20,
//     3: 30,
//     4: 40,
// }

// Результат = 110

// let sum = 0

// for(const key in obj) {
//     sum += +key + obj[key]
// }

// console.log(sum)

//? Задача 3

const obj = {
    1: 'Korea',
    2: 'Kyrgyzstan',
    3: 'Dubai',
    4: 'Singapur',
    5: 'Oslo'
}

// Kyrgyzstan
// Singapur

for(const key in obj) {
    obj[key].length >= 8 && console.log(obj[key])
}